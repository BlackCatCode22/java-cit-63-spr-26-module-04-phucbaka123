import Animal.*;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.sql.Array;
import java.util.Scanner;
import java.util.*;
import java.util.regex.*;
public class Main {
    static void main(String[] args){
        HashMap<String, Integer> TrackNum = new HashMap<>();
        ArrayList<String> TrackSpecies = new ArrayList<>();

        //Using array to track animal each species
        ArrayList<String> Lion = new ArrayList<>();
        ArrayList<String> Hyena = new ArrayList<>();
        ArrayList<String> Bear= new ArrayList<>();
        ArrayList<String> Tiger = new ArrayList<>();

        String name_line;
        String Hyena_name = "";
        String Lion_name = "";
        String Bear_name = "";
        String Tiger_name = "";

        //Elements in previous array will become key for this hashmap,
        //it will return information for each individual

        HashMap<String, String> Information = new HashMap<>();

        try {
            BufferedReader reader = new BufferedReader(new FileReader("/home/phil/IdeaProjects/Zoo/src/arrivingAnimals.txt"));
            String line;

            BufferedReader readname = new BufferedReader(new FileReader("/home/phil/IdeaProjects/Zoo/src/animalNames.txt"));
            BufferedWriter writer = new BufferedWriter(
                    new FileWriter(("/home/phil/IdeaProjects/Zoo/src/newAnimals.txt")));
            //Get the name string from the AnimalNames

            while((name_line = readname.readLine()) != null){
                if(name_line.isEmpty()){
                    continue;
                }
                if(name_line.contains("Lion")){
                    Lion_name = readname.readLine();
                    Lion_name = readname.readLine();
                    continue;
                }
                if(name_line.contains("Hyena")){
                    Hyena_name = readname.readLine();
                    Hyena_name = readname.readLine();
                    continue;
                }
                if(name_line.contains("Bear")){
                    Bear_name = readname.readLine();
                    Bear_name = readname.readLine();
                    continue;
                }
                if(name_line.contains("Tiger")){
                    Tiger_name = readname.readLine();
                    Tiger_name = readname.readLine();
                    continue;
                }
            }

            while((line = reader.readLine()) != null){
                String[] parts = line.split(",");

                if(line.contains("lion")){
                    String nextID = getNextID(Lion, "Li");
                    Lion.add(nextID);
                    String[] name = Lion_name.split(",");
                    String laugh = "Roar";
                    Animal a = parseAnimal(line, name[1], laugh);
                    Information.put(nextID, a.Information());
                    writer.write(nextID + a.Information() + "\n");
                    continue;
                }

                if(line.contains("hyena")){
                    String nextID = getNextID(Hyena, "Hy");
                    String[] name = Hyena_name.split(",");
                    String laugh = "haha";
                    Animal a = parseAnimal(line, name[1], laugh);
                    Information.put(nextID, a.Information());
                    writer.write(nextID + a.Information()+ "\n");
                    continue;
                }

                if(line.contains("bear")){
                    String nextID = getNextID(Bear, "Be");
                    Bear.add(nextID);
                    String[] name = Bear_name.split(",");
                    String laugh = "Roar";
                    Animal a = parseAnimal(line, name[1], laugh);
                    Information.put(nextID, a.Information());
                    writer.write(nextID + a.Information()+ "\n");
                    continue;
                }

                if(line.contains("tiger")){
                    String nextID = getNextID(Tiger, "Ti");
                    Tiger.add(nextID);
                    String[] name = Tiger_name.split(",");
                    String laugh = "Roar";
                    Animal a = parseAnimal(line, name[1], laugh);
                    Information.put(nextID, a.Information());
                    writer.write(nextID + a.Information()+ "\n");
                    continue;
                }
            }
            reader.readLine();
            reader.close();
            readname.close();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println(Information);


    }

    //This function is used to update new ID for array
    static String getNextID(List<String> ids, String prefix){
        int max = 0;
        Pattern p = Pattern.compile("^" +prefix+ "(\\d+)$");

        for (String id : ids){
            Matcher m = p.matcher(id);
            if(m.find()){
                int num = Integer.parseInt(m.group(1));
                if (num > max) {
                    max = num;
                }
            }
        }
        return String.format("%s%02d", prefix, max + 1);
    }
    //This function is used to get data from newanimal
    static Animal parseAnimal(String line, String name, String laugh){
        String[] parts = line.split(", ");

        int age = 0;
        String species = "";
        String gender = "";
        String park = "";
        String country = "";
        String color = "";
        String birth_season = "";

        int weight = 0;

        Pattern age_gender = Pattern.compile("(\\d+)\\s+year old\\s+(male|female)\\s+(\\w+)");
        Matcher part1 = age_gender.matcher(parts[0].trim());
        if (part1.find()){
            age = Integer.parseInt(part1.group(1));
            gender = part1.group(2);
            species = part1.group(3);
        }

        Pattern season = Pattern.compile("born in\\s+(\\w+)");
        Matcher part2 = season.matcher(parts[1].trim());
        if (part2.find()){
            birth_season = part2.group(1);
        }
        else{
            birth_season = "unknown";
        }

        Pattern Color = Pattern.compile("(.+?)\\s+color");
        Matcher part3 = Color.matcher(parts[2].trim());
        if(part3.find()){
            color = part3.group(0);
        }

        Pattern Weight = Pattern.compile("(\\d+)\\s+pounds");
        Matcher part4 = Weight.matcher(parts[3].trim());
        if(part4.find()){
            weight = Integer.parseInt(part4.group(1));
        }

        Pattern Park = Pattern.compile("from+\\s+(\\w+)+(\\w+)");
        Matcher part5 = Park.matcher(parts[4].trim());
        if(part5.find()){
            park = part5.group(1) + part5.group(2);
        }

        country = parts[5];

        Animal a = new Animal(name, age, weight, species, gender, birth_season, color,
                park, country, laugh);

        return a;

    }
}
